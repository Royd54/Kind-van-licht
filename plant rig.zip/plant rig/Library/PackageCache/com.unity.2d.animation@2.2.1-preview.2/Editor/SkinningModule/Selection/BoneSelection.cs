using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnityEditor.Experimental.U2D.Animation
{
    [Serializable]
    internal class BoneSelection : SerializableSelection<BoneCache>, IBoneSelection
    {
        protected override BoneCache GetInvalidElement() { return null; }

        public BoneCache root
        {
            get { return activeElement.FindRoot<BoneCache>(elements); }
        }

        public BoneCache[] roots
        {
            get { return elements.FindRoots<BoneCache>(); }
        }
    }
}
